package net.mikekohn.bluetemp;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Paint;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;
import java.io.InputStream;
import java.lang.Thread;

public class BlueTempView extends View
{
  private Paint paint;
  private float celcius = 0;
  private float fahr = 0;
  private Thread thread;
  private InputStream in;
  private boolean keep_running;
  private int width = 0;
  private int height = 0;
  private int x0,y0, x1,y1;
  private Bitmap thermometer_image;
  private int thermometer_x0;
  private int thermometer_y0;
  private int mercury_x0;
  private int mercury_y0;
  private float scale;

  public BlueTempView(Context context, AttributeSet attrs)
  {
    super(context, attrs);

    paint=new Paint();
    Resources res = context.getResources();
    thermometer_image = BitmapFactory.decodeResource(res, R.drawable.thermometer);

  }

  protected void onDraw(Canvas canvas)
  {
    int celcius_i;
    int fahr_i;

    super.onDraw(canvas);

    canvas.drawColor(0xff000000);
    canvas.drawBitmap(thermometer_image, thermometer_x0, thermometer_y0, null);

    paint.setTextSize(40);
    paint.setColor(0xffffffff);

    celcius_i = (int)(celcius * 10);
    fahr_i = (int)(fahr * 10);

    paint.setStyle(Paint.Style.FILL);
    canvas.drawText((celcius_i/10)+"."+(celcius_i%10)+"C", 10, 50, paint);
    canvas.drawText((fahr_i/10)+"."+(fahr_i%10)+"F", 10, 100, paint);

    paint.setColor(0xffcd464d);
    //paint.setColor(0xff0000ff);
    //canvas.drawRect(thermometer_x0+60, thermometer_y0+336-(int)((celcius+40)*263/90), thermometer_x0+67, thermometer_y0+336, paint);
    canvas.drawRect(mercury_x0, mercury_y0-(int)((celcius+40)*scale), mercury_x0+11, mercury_y0, paint);

    //canvas.drawRect(thermometer_x0, thermometer_y0, thermometer_x0+2, thermometer_y0+height-10, paint);
    //canvas.drawRect(thermometer_x0+thermometer_image.getWidth(), thermometer_y0, thermometer_x0+thermometer_image.getWidth()+2, thermometer_y0+height-10, paint);


    //paint.setStyle(Paint.Style.STROKE);
    //paint.setColor(0xffaa0000);
    //canvas.drawRect(x0, y0, x1, y1, paint);
    //canvas.drawCircle(width/2, y1, 30, paint);

    //paint.setStyle(Paint.Style.FILL);
    //paint.setColor(0xffaa0000);
    //canvas.drawRect(x0, y1-fahr, x1, y1, paint);
    //canvas.drawCircle(width/2, y1, 28, paint);
  }

  public void startTempThread(InputStream in)
  {
    this.in = in;
    keep_running = true;
    thread = new Thread(runnable);
    thread.start();
  }

  public void kill()
  {
    keep_running = false;
  }

  final Runnable runnable = new Runnable()
  {
    public void run()
    {
      int[] temp = new int[2];
      int index = -2;
      int ch,c,d;

      while(keep_running)
      {
        try
        {
          ch = in.read();
          // System.out.println("Read in "+ch);

          if (index < 0)
          {
            if (ch == 0xff) { index++; }
            else { index = -2; }
          }
            else
          {
            // System.out.println("index="+index);
            temp[index++] = ch;
            if (index == 2)
            {
              c = (temp[1] << 4) | (temp[0] >> 4);
              d = temp[0]&0x0f;

              if ((c&0x800) != 0)
              {
                c = -(~c + 1);
              }

              celcius = (float)c + ((float)d/8);
              fahr = celcius * 9 / 5 + 32;

              postInvalidate();
              index = -2;
            }
          }
        }
        catch (Exception e) { System.out.println("BlueTemp problem: "+e.toString()); }
      }
    }
  };

  protected void onSizeChanged(int w, int h, int oldw, int oldh)
  {
    width = getWidth();
    height = getHeight();

    x0 = width/2-20;
    x1 = width/2+20;
    y0 = height/2;
    y1 = height/2+140;

    thermometer_x0 = width/2;
    thermometer_y0 = 10; 

    mercury_x0 = thermometer_x0 + thermometer_image.getWidth() / 2 - 4;
    mercury_y0 = thermometer_y0 + (thermometer_image.getHeight() * 336) / 416;

    scale = ((float)263/(float)90) * ((float)thermometer_image.getHeight() / (float)416);


    System.out.println(thermometer_image.getWidth()+" "+thermometer_image.getHeight());
    System.out.println(width+" "+height);
  }
}



