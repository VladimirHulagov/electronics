package net.mikekohn.bluetemp;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ListView;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Set;
import java.util.UUID;

public class BlueTemp extends Activity
{
  private ListView device_list;
  private ArrayAdapter list_adapter = null;
  private BluetoothSocket socket = null;
  private BluetoothDevice[] bluetooth_devices = null;
  private OutputStream out = null;
  private InputStream in = null;

  /** Called when the activity is first created. */
  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.title);
  }

  @Override
  public void onStop()
  {
    super.onStop();

    BlueTempView blue_view = (BlueTempView)findViewById(R.id.bluetemp);
    if (blue_view != null)
    {
      blue_view.kill();
    }

    System.out.println("closing socket");

    try
    {
      if (in != null) in.close();
      if (out != null) out.close();
      if (socket != null) socket.close();
    }
    catch (Exception e) { System.out.println(e.toString()); }

    socket = null;
  }

  public void continue_click(View view)
  {
    setContentView(R.layout.main);

    BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
    String[] devices_strings = { "No Adapter Found" };

    if (adapter != null)
    {
      Set<BluetoothDevice> devices = adapter.getBondedDevices();
      //devices = new String[devices.size()];
      devices_strings = new String[devices.size()];
      bluetooth_devices = new BluetoothDevice[devices.size()];
      Iterator iter = devices.iterator();

      int i = 0;
      while(iter.hasNext())
      {
        bluetooth_devices[i] = (BluetoothDevice)iter.next();
        //System.out.println(iter.next());
        devices_strings[i] = bluetooth_devices[i].getName()+"  "+bluetooth_devices[i].getAddress();
        i++;
      }
    }

    device_list = (ListView)findViewById(R.id.device_list);
    device_list.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, devices_strings));

    device_list.setOnItemClickListener(new OnItemClickListener()
    {
      @Override
      public void onItemClick(AdapterView<?> parent, View view, int position, long id)
      {
        System.out.println("position: "+position+"   id:"+id+"   "+device_list.getItemAtPosition(position).toString());

        try
        {
          socket = bluetooth_devices[position].createRfcommSocketToServiceRecord(UUID.fromString("00001101-0000-1000-8000-00805F9B34FB"));
          socket.connect();
          out = socket.getOutputStream();
          in = socket.getInputStream();
          //byte[] mike = { 'm', 'i', 'k', 'e' };
          //out.write(mike);
          //out.flush();
          BlueTempView blue_view = (BlueTempView)findViewById(R.id.bluetemp);
          blue_view.startTempThread(in);
        }
        catch (Exception e) { System.out.println(e.toString()); }

        device_list.setVisibility(View.GONE);
      }
    }
    );
  }
}


